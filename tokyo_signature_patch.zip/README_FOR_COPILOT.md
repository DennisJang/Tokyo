# Tokyo Magazine — signature_line · 가격 링크 · Practical 마이그레이션

## 작업 요청 (Copilot에게)

이 zip을 풀고 아래 6개 파일을 GitHub repo (https://github.com/DennisJang/Tokyo) 의 정확히 같은 경로에 배치해줘. 신규/덮어쓰기 표시대로.

```
src/
└── app/
    ├── components/
    │   ├── PlaceCard.tsx          ← 덮어쓰기
    │   ├── CardDetailSheet.tsx    ← 덮어쓰기
    │   └── SignatureLine.tsx      ← 신규
    ├── data/
    │   ├── tripGuide.ts           ← 덮어쓰기 (전면 재작성)
    │   └── trip_guide_v2.json     ← 신규 (콘텐츠 데이터)
    └── utils/                     ← 신규 폴더
        └── signatureParser.ts     ← 신규
```

**건드리지 말 것 (호환되도록 작업했음):**
- `src/app/App.tsx`
- `src/main.tsx`
- `src/app/components/AppendixPractical.tsx`
- `src/app/components/ChapterSection.tsx`
- `src/app/components/BottomMapSheet.tsx`
- `src/app/components/DayTrips.tsx`
- `src/app/components/EditorNote.tsx`
- `src/app/components/IssueCover.tsx`
- `src/app/components/MagazineHeader.tsx`
- `src/styles/*`, `src/app/components/ui/*`, `src/app/components/figma/*`

## 변경 요약

1. **데이터 소스 교체** — 하드코딩된 `tripGuide.ts` → `trip_guide_v2.json` import. 어댑터 내장.
2. **signature_line 렌더링** — 카드 콜랩스/상세 시트 양쪽에 추가.
3. **가격 → Google Maps 링크** — 상세 시트의 signature_line에서, 가격 토큰(예: "2,500엔")만 자동 감지해 `https://www.google.com/maps/place/?q=place_id:{ID}` 로 링크. "무료"는 텍스트.
4. **Practical 콘텐츠** — v2 JSON의 `appendix.practical.subcategories` 자동 사용 (string[] → {id,text} 어댑터가 변환).

## 검증 단계

```bash
# 1) 의존성 그대로 (lucide-react만 사용 — 이미 있음)
npm install

# 2) 타입체크
npx tsc --noEmit

# 3) 빌드
npm run build

# 4) 로컬 확인
npm run dev
```

확인 포인트:
- [ ] 카드 하단에 작은 글씨로 signature_line 한 줄이 보이는가
- [ ] 카드를 탭해서 상세 시트를 열면 one_liner 아래에 signature_line이 다시 보이는가
- [ ] 가격 토큰(예: "입장 2,500엔")에 밑줄이 있고 클릭하면 새 탭에서 Google Maps가 열리는가
- [ ] "무료"는 링크 아닌 일반 텍스트인가
- [ ] Practical 섹션의 5개 카테고리가 v2 콘텐츠로 바뀌었는가
- [ ] 콘솔 에러 없이 모든 챕터(시부야~아자부주반) + Day Trips 렌더되는가

## 알려진 한계

- **이미지**: v2 JSON에 직접 URL이 없어서 entity_id → Unsplash 정적 매핑으로 대체. 새 entity는 `theme_tags` 기반 fallback. 이미지 fetch 파이프라인은 별도 PR.
- **공식 사이트 링크**: entities_graph에 `official_url` 필드가 없어 Google Maps만 지원. affordance는 외부 링크 아이콘만 (카피 없음).
- **가격 정규식**: `숫자+엔/円`만 감지. `¥` 기호나 `달러`가 v2에 등장하면 `src/app/utils/signatureParser.ts`의 `PRICE_RE` 수정.

## 본질 분해 (커밋 메시지/PR 설명에 활용)

### 변경의 4개 독립 결정
1. **데이터 스키마**: 코드 하드코딩 → JSON single source. 어댑터로 인터페이스 호환 유지.
2. **signature_line 파싱**: ` · ` split + 가격 정규식 (순수 함수, `utils/signatureParser.ts`).
3. **렌더 모드 분기**: 카드(텍스트만) vs 시트(링크 활성) — button-in-button 충돌 회피.
4. **링크 대상**: Google Maps `place_id` URL — 사용자가 가장 빠르게 최신 정보(영업/가격/리뷰)에 도달하는 단일 진입점.

### 단일 책임 원칙
- `signatureParser.ts` — 문자열 → 토큰 (UI 무관)
- `SignatureLine.tsx` — 토큰 → JSX (parser 의존)
- `tripGuide.ts` — JSON → 타입 (어댑터)
- 카드/시트 컴포넌트는 `<SignatureLine>` 한 줄 추가만, 기존 로직 무손실
